insert into car (brand) values('Honda');
insert into car (brand) values('Hyundai');
insert into car (brand) values('Suzuki');
insert into car (brand) values('Audi');
insert into car (brand) values('Jaguar');