package com.kgisl.springtst;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringtstApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringtstApplication.class, args);
	}

}
